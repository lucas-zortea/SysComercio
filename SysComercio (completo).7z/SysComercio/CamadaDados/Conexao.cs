﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaDados
{
    class Conexao
    {
        public static string Cn = "Data Source = DESKTOP-CFCR613; Initial Catalog = dbcomercio; Integrated Security=true";
    }
}
